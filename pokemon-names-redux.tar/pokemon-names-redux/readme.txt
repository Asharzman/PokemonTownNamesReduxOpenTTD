Pokemon Region town and city names, including Kanto, Johto, Hoenn, Sinnoh, Unova, Kalos, Orre, Oblivia, Almia, Fiore, anime series and mentioned locations. Original mod was made by Grenmon.
