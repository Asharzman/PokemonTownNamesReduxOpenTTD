Pokemon Region town and city names, including Kanto, Johto, Hoenn, Sinnoh, Unova, Kalos, Orre, Oblivia, Almia and Fiore
